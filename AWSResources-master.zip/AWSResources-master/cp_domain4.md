# Domain 4

* Domain 4: Billing and Pricing
  * 4.1 Compare and contrast the various pricing models for AWS
  * 4.2 Recognize the various account structures in relation to AWS billing and pricing
  * 4.3 Identify resources available for billing support
